﻿namespace StudentTeacher_BackEnd_.Models.Domains
{
    public class Teacher
    {
        public int Id { get; set; }
        public  string? Name { get; set; }
        public  string? Department {get;set;}
        
    }

}

