﻿namespace StudentTeacher_BackEnd_.Models.MongoDomain
{
    public class BookStoreDatabaseSettings 
    {
        public string? ConnectionString { get; set; }
        public string? DatabaseName { get; set; }
       public string? BooksCollectionName { get; set; }

    }
}
